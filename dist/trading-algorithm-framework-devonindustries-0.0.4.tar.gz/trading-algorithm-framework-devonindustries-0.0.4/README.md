# Trading Algorithm Framework

A module containing useful packages for testing and writing trading algorithms. The idea of this package is to simulate a stock exchange allowing an algorithm to enter or leave positions. The user will be able to evaluate the performance of the algorithm using various tools available in this package.
