# Define a class to handle exchanges (this will be properly implemented later)
class Exchange:
    pass

# Define a class to store an actual stock with all of its data
class Stock:
    pass 
